mic_raw <- read.delim("C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/mrna_insertions_cn_combined.txt")
mic <- na.omit(mic_raw)

mic_cnn<-subset(mic, mic$cn==1)
mic_cnv<-subset(mic, mic$cn!=1)

plot(log2(mic_cnn$mrna), log2(mic_cnn$insertions))
fit<-lm(log2(mic_cnn$insertions) ~ log2(mic_cnn$mrna))
summary(fit)

plot(log2(mic_cnv$mrna), log2(mic_cnv$insertions))
fit<-lm(log2(mic_cnv$insertions) ~ log2(mic_cnv$mrna))
summary(fit)


