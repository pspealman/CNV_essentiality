# -*- coding: utf-8 -*-
"""
Created on Wed Nov  2 12:05:39 2022

@author: pspea
"""
import numpy as np
import pandas as pd

#import plotly.graph_objects as go

import plotly.io as pio
pio.renderers.default = "browser"


import plotly.graph_objects as go

#output_figure_name = ('C:/Gresham/tiny_projects/Project_Grace/figures/insertions_CNV_map.pdf')
copy_number_filename = ('C:/Gresham/tiny_projects/Project_Grace/relative_depth_DNA_corrected_v3.txt')
df = pd.read_table(copy_number_filename, index_col=0)
cn_dict = df.to_dict('index')

strain_list = list(cn_dict['YKR039W'].keys())
strain_list.sort()

strain_list = ['DGY1657','DGY1728','DGY1734','DGY1736','DGY1740','DGY1744','DGY1747','DGY1751']
#We need to populate the gene list with those genes that are detected in every strain - 
# otherwise there will be misalignement on between genes between strains on the global heatmap

# gene_count_strain = {}

# for istype in ['Obs']:
#     for evo_strain in strain_list:
#         if evo_strain != 'DGY1657':
#             inserts_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/baySeq/DGY1657_{}_{}_bs.tab').format(evo_strain, istype)
#             inserts_results_file = open(inserts_results_filename)
#             df = pd.read_table(inserts_results_filename, index_col=0)
#             inserts_results = df.to_dict('index')
            
#             for gene in inserts_results:
#                 if gene[0] == 'Y':
#                     if gene not in gene_count_strain:
#                         gene_count_strain[gene] = set()
                        
#                     gene_count_strain[gene].add(evo_strain)
                    
                    
# complete_gene_list = set()
# strain_max = 0

# for gene in gene_count_strain:
#     if len(gene_count_strain[gene]) >= strain_max:
#         strain_max = len(gene_count_strain[gene])
    
#     if len(gene_count_strain[gene]) >= 7:
#         complete_gene_list.add(gene)
#     else:
#         print(gene)
                         

# # for gene in complete_gene_list:
# #     if gene[0] == 'Y':
# #         if gene not in gene_count_strain:
# #             gene_count_strain[gene] = True
            
# #         for strain in strain_list:
# #             if strain not in  cn_dict[gene]:
# #                 gene_count_strain[gene] = False
# #                 1/0
            
    

# ykl_list = []
# ykr_list = []
# for gene in complete_gene_list:
#     if 'YKL' in gene:
#         ykl_list.append(gene)
#     if 'YKR' in gene:
#         ykr_list.append(gene)

# ykr_list.sort()
# ykl_list.sort(reverse=True)

# yk_list = ykl_list + ykr_list

# exp = []

# for strain in strain_list:
#     exp_sub = []
#     for gene in yk_list:
#         exp_sub.append(round(cn_dict[gene][strain]))
#     exp.append(exp_sub)
        
        

# fig = go.Figure(data=go.Heatmap(
#                    z=exp,
#                    x=yk_list,
#                    y=strain_list,
#                    hoverongaps = False,
#                    colorscale= 'Reds'))
# fig.show()
# #fig.write_image(output_figure_name)

# # colorscale= 'RdBu_r'

# #output_figure_name = ('C:/Gresham/tiny_projects/Project_Grace/figures/Insertions_Log2FC_map_GR.pdf')
# log2fc_dict = {}

inserts_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/insertions/global_normalized_insertionPerGene.txt')
inserts_results_file = open(inserts_results_filename)
df = pd.read_table(inserts_results_filename, index_col=0)
inserts_results = df.to_dict('index')

for gene in inserts_results:
    for strain in strain_list:
        if gene in cn_dict:
            if strain in cn_dict[gene]:
                cn = cn_dict[gene][strain]
                if cn > 1:
                    inserts_results[gene][strain] = inserts_results[gene][strain]/cn
                    
                    
inserts_results_new = pd.DataFrame.from_dict(inserts_results, orient='index')

output_inserts_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/global_normalized_insertionPerGene_cn_corrected.txt')

inserts_results_new.to_csv(path_or_buf=output_inserts_results_filename, na_rep = np.nan)
#
mrna_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/coverage_table_rnaseq_corrected.txt')
mrna_results_file = open(mrna_results_filename)
df = pd.read_table(mrna_results_filename, index_col=0)
mrna_results = df.to_dict('index')

count_dict = {}
count_correction_dict = {}

for gene in mrna_results:
    for strain in mrna_results[gene]:
        
        if strain not in count_dict:
            count_dict[strain] = 0
            
        count_dict[strain] += mrna_results[gene][strain]
        
ismin = np.inf

for strain in count_dict:
    if count_dict[strain] < ismin:
        ismin = count_dict[strain]

for gene in mrna_results:
    for strain in strain_list:
        if gene in cn_dict:        
            if strain in cn_dict[gene]:
                
                
                cn = max(cn_dict[gene][strain],1)
                #if cn > 1:
                for rep in range(1,5):
                    strain_replicate = ('{}-{}').format(strain, rep)
                    
                    if strain_replicate in mrna_results[gene]:
                        count_correction = ismin/count_dict[strain_replicate]
                        count_corrected_reads = mrna_results[gene][strain_replicate]*count_correction
                        mrna_results[gene][strain_replicate] = round(count_corrected_reads/cn)
                
mrna_results_new = pd.DataFrame.from_dict(mrna_results, orient='index')
output_mrna_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/coverage_table_rnaseq_cn_corrected.txt')

mrna_results_new.to_csv(path_or_buf=output_mrna_results_filename, na_rep = np.nan)

mrna_median_results = {}

for gene in mrna_results:
    if gene not in mrna_median_results:
        mrna_median_results[gene] = {}
        
    for strain in strain_list:
        if strain not in mrna_median_results[gene]:
            mrna_median_results[gene][strain] = 0
        
        temp_list = []    
        
        for rep in range(1,5):
            strain_replicate = ('{}-{}').format(strain, rep)
            if strain_replicate in mrna_results[gene]:
                temp_list.append(mrna_results[gene][strain_replicate])
                
        mrna_median_results[gene][strain] = np.median(temp_list)
        
mrna_median_results_df = pd.DataFrame.from_dict(mrna_median_results, orient='index')
mrna_median_results_df_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/coverage_table_rnaseq_cn_median.txt')

mrna_median_results_df.to_csv(path_or_buf=mrna_median_results_df_filename, na_rep = np.nan)
                
output_xyz_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/mrna_insertions_cn_combined.txt')
output_xyz =  open(output_xyz_filename, 'w')

header = ('mrna\tinsertions\tcn\n')

output_xyz.write(header)

for gene in mrna_median_results:
    if gene in inserts_results:
        if gene in cn_dict:
            for strain in strain_list:
                #if strain != 'DGY1657':
                    if strain in mrna_median_results[gene]:
                        if strain in inserts_results[gene]:
                            if strain in cn_dict[gene]:
                                x = mrna_median_results[gene][strain]
                                #/max(mrna_median_results[gene]["DGY1657"],1)
                                y = inserts_results[gene][strain]
                                #/max(inserts_results[gene]["DGY1657"],1)
                                z = cn_dict[gene][strain]
                                
                                if x == 0:
                                    x = 1
                                
                                if y == 0:
                                    y = 1
                                
                                outline = ('{x}\t{y}\t{z}\n').format(
                                    x = x, y = y, z = z)
                                
                                output_xyz.write(outline)
                            
output_xyz.close()
                    
            
            