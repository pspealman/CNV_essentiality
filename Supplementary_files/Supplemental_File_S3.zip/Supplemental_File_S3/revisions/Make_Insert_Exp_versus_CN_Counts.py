# -*- coding: utf-8 -*-
"""
Created on Wed Nov  2 12:05:39 2022

@author: pspea
"""
import numpy as np
import pandas as pd
import random
from scipy.stats import fisher_exact

#import plotly.graph_objects as go

import plotly.io as pio
pio.renderers.default = "browser"


import plotly.graph_objects as go

#output_figure_name = ('C:/Gresham/tiny_projects/Project_Grace/figures/insertions_CNV_map.pdf')
copy_number_filename = ('C:/Gresham/tiny_projects/Project_Grace/relative_depth_DNA_corrected_v3.txt')
df = pd.read_table(copy_number_filename, index_col=0)
cn_dict = df.to_dict('index')

strain_list = list(cn_dict['YKR039W'].keys())
strain_list.sort()

strain_list = ['DGY1657','DGY1728','DGY1734','DGY1736','DGY1740','DGY1744','DGY1747','DGY1751']


inserts_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/insertions/global_normalized_insertionPerGene.txt')
inserts_results_file = open(inserts_results_filename)
df = pd.read_table(inserts_results_filename, index_col=0)
inserts_results = df.to_dict('index')

for gene in inserts_results:
    for strain in strain_list:
        if gene in cn_dict:
            if strain in cn_dict[gene]:
                cn = cn_dict[gene][strain]
                if cn > 1:
                    inserts_results[gene][strain] = inserts_results[gene][strain]/cn
                    
                    
inserts_results_new = pd.DataFrame.from_dict(inserts_results, orient='index')

output_inserts_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/global_normalized_insertionPerGene_cn_corrected.txt')

inserts_results_new.to_csv(path_or_buf=output_inserts_results_filename, na_rep = np.nan)
#
mrna_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/coverage_table_rnaseq_corrected.txt')
mrna_results_file = open(mrna_results_filename)
df = pd.read_table(mrna_results_filename, index_col=0)
mrna_results = df.to_dict('index')

count_dict = {}
count_correction_dict = {}

for gene in mrna_results:
    for strain in mrna_results[gene]:
        
        if strain not in count_dict:
            count_dict[strain] = 0
            
        count_dict[strain] += mrna_results[gene][strain]
        
ismin = np.inf

for strain in count_dict:
    if count_dict[strain] < ismin:
        ismin = count_dict[strain]

for gene in mrna_results:
    for strain in strain_list:
        if gene in cn_dict:        
            if strain in cn_dict[gene]:
                
                
                cn = max(cn_dict[gene][strain],1)
                #if cn > 1:
                for rep in range(1,5):
                    strain_replicate = ('{}-{}').format(strain, rep)
                    
                    if strain_replicate in mrna_results[gene]:
                        count_correction = ismin/count_dict[strain_replicate]
                        count_corrected_reads = mrna_results[gene][strain_replicate]*count_correction
                        mrna_results[gene][strain_replicate] = round(count_corrected_reads/cn)
                
                


mrna_results_new = pd.DataFrame.from_dict(mrna_results, orient='index')
output_mrna_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/coverage_table_rnaseq_cn_corrected.txt')

mrna_results_new.to_csv(path_or_buf=output_mrna_results_filename, na_rep = np.nan)

mrna_median_results = {}

for gene in mrna_results:
    if gene not in mrna_median_results:
        mrna_median_results[gene] = {}
        
    for strain in strain_list:
        if strain not in mrna_median_results[gene]:
            mrna_median_results[gene][strain] = 0
        
        temp_list = []    
        
        for rep in range(1,5):
            strain_replicate = ('{}-{}').format(strain, rep)
            if strain_replicate in mrna_results[gene]:
                temp_list.append(mrna_results[gene][strain_replicate])
                
        mrna_median_results[gene][strain] = np.median(temp_list)
        
#DSGs
#YKL166C	14.65627664	1.508743981	0.90273042	1.671311775	0.094660112	0.999773524
#34 0.54782004
#36 1.016586754
#40 0.507471879
#44 0.975457224
#47 0.530228987
#51 0.730346772
#YKL042W	8.589275521	1.742065381	1.214126135	1.434830641	0.151335364	0.999773524
#34 -1.344311965
#36 -2.112160537
#44 
#40 -4.92577454
#47 -3.581590572
#51 -3.965154342

gene_set = set(["YKL042W", "YKL166C"])


for gene in gene_set:
    print(mrna_median_results[gene])
    
        
mrna_median_results_df = pd.DataFrame.from_dict(mrna_median_results, orient='index')
mrna_median_results_df_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/coverage_table_rnaseq_cn_median.txt')

mrna_median_results_df.to_csv(path_or_buf=mrna_median_results_df_filename, na_rep = np.nan)
                
output_xyz_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/mrna_insertions_cn_ratio_combined.txt')
output_xyz =  open(output_xyz_filename, 'w')

header = ('mrna\tinsertions\tcn\n')

output_xyz.write(header)

for gene in mrna_median_results:
    if gene in inserts_results:
        if gene in cn_dict:
            for strain in strain_list:
            #for strain in ['DGY1728']:
                if gene[0:2] == 'YK':
                    if strain in mrna_median_results[gene]:
                        if strain in inserts_results[gene]:
                            if strain in cn_dict[gene]:
                                x = mrna_median_results[gene][strain]/max(mrna_median_results[gene]["DGY1657"],1)
                                y = inserts_results[gene][strain]/max(inserts_results[gene]["DGY1657"],1)
                                z = cn_dict[gene][strain]
                                
                                if x == 0:
                                    x = 1
                                
                                if y == 0:
                                    y = 1
                                
                                outline = ('{x}\t{y}\t{z}\n').format(
                                    x = x, y = y, z = z)
                                
                                output_xyz.write(outline)
                            
output_xyz.close()
                    
            
            
### co-proportional 
def make_covar_check_list(strain):
    check_set = set()

    cnv_sig_source_file_name = ('C:/Gresham/tiny_projects/Project_Grace/supplemental_figures/Supplemental_Fig2C_SigOutliers_CNV_{}.txt').format(strain)
    df = pd.read_table(cnv_sig_source_file_name, index_col=0)
    cnv_sig_source_dict = df.to_dict('index')
    
    for gene in list(cnv_sig_source_dict.keys()):
        check_set.add(gene)
    
    cnn_sig_source_file_name = ('C:/Gresham/tiny_projects/Project_Grace/supplemental_figures/Supplemental_Fig2C_SigOutliers_{}.txt').format(strain)
    df = pd.read_table(cnn_sig_source_file_name, index_col=0)
    cnn_sig_source_dict = df.to_dict('index')
    
    for gene in list(cnn_sig_source_dict.keys()):
        if cnn_sig_source_dict[gene][strain] == 1:
            check_set.add(gene)
            
    return(check_set)

def make_background_check_list(strain, check_set):
    background_set = set()
    
    size = len(check_set)*10
    
    count = 0 
    while count <= size:
        gene = random.choice(list(mrna_median_results.keys()))

        if (gene[0] == 'Y') and (gene not in check_set):
            if strain in mrna_median_results[gene]:
                background_set.add(gene)
                count+=1
    
    return(background_set)
                
        


def run_covar_check(gene_set):
    covar_dict = {}
    
    for gene in gene_set:
        if gene in mrna_median_results:
            if strain in mrna_median_results[gene]:
                for cov_gene in mrna_median_results:
                    if (gene != cov_gene) and (cov_gene[0] == 'Y'):
                        #print(gene, cov_gene)
                        
                        gene_strain_val = np.log2(max(1,mrna_median_results[gene][strain])/max(1,mrna_median_results[gene]['DGY1657']))
                        cov_gene_strain_val = np.log2(max(1,mrna_median_results[cov_gene][strain])/max(1,mrna_median_results[cov_gene]['DGY1657']))                
                        
                        if gene_strain_val*cov_gene_strain_val != 0:
                            strain_ratio = gene_strain_val-cov_gene_strain_val
                            
                            direction_list = [strain_ratio]
                            
                            for cov_strain in strain_list:
                                if strain != cov_strain:
                                    # print(strain, cov_strain)
                                    # print(gene_strain_val, mrna_median_results[gene][strain], mrna_median_results[gene]['DGY1657'])
                                    # print(cov_gene_strain_val, mrna_median_results[cov_gene][strain], mrna_median_results[cov_gene]['DGY1657'])
                                    
                                    gene_cov_strain_val = np.log2(max(1,mrna_median_results[gene][cov_strain])/max(1,mrna_median_results[gene]['DGY1657']))
                                    cov_gene_cov_strain_val = np.log2(max(1,mrna_median_results[cov_gene][cov_strain])/max(1,mrna_median_results[cov_gene]['DGY1657']))             
                
                                    # print(gene_cov_strain_val, mrna_median_results[gene][cov_strain], mrna_median_results[gene]['DGY1657']) 
                                    # print(cov_gene_cov_strain_val, mrna_median_results[cov_gene][cov_strain], mrna_median_results[cov_gene]['DGY1657'])
                
                                    if gene_cov_strain_val*cov_gene_cov_strain_val != 0:                                        
                                        cov_strain_ratio = gene_cov_strain_val-cov_gene_cov_strain_val
                                                             
                                        direction_list.append(cov_strain_ratio)
                                    
                            if round_robin(direction_list):
                                #print(gene, cov_gene)
                                if gene not in covar_dict:
                                    covar_dict[gene] = {}
                                    
                                if cov_gene not in covar_dict[gene]:
                                    covar_dict[gene][cov_gene] = direction_list
    return(covar_dict)

def return_direction(val):
    if val > 0:
        return('up')
    else:
        return('down')
    
def round_robin(val_list):
    
    if len(val_list) < 6:
        return(False)

    base_val = val_list[0]
    lower_bound = base_val*0.75
    higher_bound = base_val*1.25
    
    for val in val_list[1:]:
        if not (lower_bound < val and  higher_bound > val):
            return(False)
        
    #print(val_list)
    return(True)
    
    
            
        
    

strain_list = ['DGY1728','DGY1734','DGY1736','DGY1740','DGY1744','DGY1747','DGY1751']

output_file =  open('C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/outliers_with_significant_covariants.tsv', 'w')

global_covar_dict = {}

for strain in strain_list:

    check_set = make_covar_check_list(strain)
    
    covar_dict = run_covar_check(gene_set)
    
    for gene in covar_dict:
        for cov_gene in covar_dict[gene]:
            direction_list = covar_dict[gene][cov_gene]
            
            prop = ''
            for each in direction_list:
                prop += str(each) + '\t'
                
            prop = prop[:-1]
            
            outline =('{strain}\t{gene}\t{cov_gene}\t{prop}\n').format(
                strain = strain, gene = gene, cov_gene = cov_gene, prop = prop)
            
            output_file.write(outline)
    
    background_set = make_background_check_list(strain, check_set)
    
    background_covar_dict = run_covar_check(background_set)
        
    x = 0
    
    for gene in covar_dict:
        for cogene in covar_dict[gene]:
            x+=1
            
    m = len(covar_dict)*5905
            
    y = 0
    
    for gene in background_covar_dict:
        for cogene in background_covar_dict[gene]:
            y+=1

    n = len(background_covar_dict)*5905
    print(strain)
    print(x, m, y, n)
    results = fisher_exact([[x,m],[y,n]])
    print(results)
    
    global_covar_dict[strain] = {'check_set':check_set,
                                 'fet':[[x,m],[y,n]],
                                 'results':results}

output_file.close()

def make_covar_cnv_list(strain):
    check_set = set()

    cnv_sig_source_file_name = ('C:/Gresham/tiny_projects/Project_Grace/supplemental_figures/Supplemental_Fig2C_SigOutliers_CNV_{}.txt').format(strain)
    df = pd.read_table(cnv_sig_source_file_name, index_col=0)
    cnv_sig_source_dict = df.to_dict('index')
    
    for gene in list(cnv_sig_source_dict.keys()):
        check_set.add(gene)
                
    return(check_set)



report_set = set()

for strain in global_covar_dict:
    cnv_set = make_covar_cnv_list(strain)
    check_set = global_covar_dict[strain]["check_set"]
    
    for gene in check_set:
        if gene in cnv_set:
            print(strain, gene)
            report_set.add(gene)
            
            
            
            
    

