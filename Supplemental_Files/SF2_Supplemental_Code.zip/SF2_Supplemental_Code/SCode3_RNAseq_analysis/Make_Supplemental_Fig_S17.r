#Supplemental_Fig_S17 
library(scales)
mic_raw <- read.delim("C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/mrna_insertions_cn_combined.txt")
mic <- na.omit(mic_raw)

mic_cnn<-subset(mic, mic$cn==1)
mic_cnv<-subset(mic, mic$cn!=1)

pdf("C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/SFig11B_cnn_notFC.pdf")
plot(log2(mic_cnn$insertions), log2(mic_cnn$mrna), col = alpha("black",0.2))
fit<-lm(log2(mic_cnn$mrna) ~ log2(mic_cnn$insertions))
abline(fit)
summary(fit)
dev.off()

pdf("C:/Gresham/tiny_projects/Project_Grace/Review_GB/trans_per_insert/SFig11C_cnn_notFC.pdf")
plot(log2(mic_cnv$insertions), log2(mic_cnv$mrna), col = alpha("black",0.2))
fit<-lm(log2(mic_cnv$mrna) ~ log2(mic_cnv$insertions))
abline(fit)
summary(fit)
dev.off()