# -*- coding: utf-8 -*-
"""
Created on Sat Mar 11 21:53:44 2023

@author: pspea
"""

import pandas as pd
import numpy as np


insert_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/unity.csv')
insert_results_file = open(insert_results_filename)
df = pd.read_table(insert_results_filename, index_col=1, sep=',')
insert_results = df.to_dict('index')

only_nan_hist_dict = {}
halfhalf_hist_dict = {}
only_num_hist_dict = {}



insert_results_filename =  ('C:/Gresham/tiny_projects/Project_Grace/Review_GB/unity.csv')
insert_results_file = open(insert_results_filename)
df = pd.read_table(insert_results_filename, index_col=1, sep=',')
insert_results = df.to_dict('index')

only_nan_hist_dict = {}
halfhalf_hist_dict = {}
only_num_hist_dict = {}

for gene in insert_results:
    nt_length = (insert_results[gene]['V1']*3)+3
    minimum = 50
    #minimum = nt_length*0.12
    rep1 = np.isnan(insert_results[gene]['X1657_1'])
    rep2 = np.isnan(insert_results[gene]['X1657_2'])
    
    if rep1 and rep2:
        if nt_length not in only_nan_hist_dict:
            only_nan_hist_dict[nt_length] = 0
        
        only_nan_hist_dict[nt_length] += 1
        
    if (rep1 or rep2) and not (rep1 and rep2):
        if insert_results[gene]['X1657_1']>=minimum or insert_results[gene]['X1657_2']>=minimum: 
            if nt_length not in halfhalf_hist_dict:
                halfhalf_hist_dict[nt_length] = 0
            
            halfhalf_hist_dict[nt_length] += 1
        
    if not rep1 and not rep2:
        if (insert_results[gene]['X1657_1'] + insert_results[gene]['X1657_2'])>=minimum:
            if nt_length not in only_num_hist_dict:
                only_num_hist_dict[nt_length] = 0
            
            only_num_hist_dict[nt_length] += 1
        
def put_in_bin(nt, hist_dict):
    for hist in hist_dict:
        start = int(hist.split('-')[0])
        stop = int(hist.split('-')[1])
        
        if (nt >= start) and (nt <= stop):
            return(hist)
        
hist_dict = {
    '0-100':{'nan':0, 'hnh':0, 'num':0, 'tot':0}, 
    '101-200':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '201-300':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '301-400':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '401-500':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '501-1000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '1001-2000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '2001-3000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '3001-4000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '4001-5000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '5001-6000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},
    '6001-15000':{'nan':0, 'hnh':0, 'num':0, 'tot':0},    
    }

for nt in range(0,14800):
    hist = put_in_bin(nt, hist_dict)
    
    if nt in only_nan_hist_dict:
        hist_dict[hist]['nan']+=only_nan_hist_dict[nt]
        hist_dict[hist]['tot']+=only_nan_hist_dict[nt]
        
    if nt in halfhalf_hist_dict:
        hist_dict[hist]['hnh']+=halfhalf_hist_dict[nt]
        hist_dict[hist]['tot']+=halfhalf_hist_dict[nt]
        
    if nt in only_num_hist_dict:
        hist_dict[hist]['num']+=only_num_hist_dict[nt]
        hist_dict[hist]['tot']+=only_num_hist_dict[nt]
                
hist_pct_dict = {
    '0-100':{'nan':0, 'hnh':0, 'num':0}, 
    '101-200':{'nan':0, 'hnh':0, 'num':0},
    '201-300':{'nan':0, 'hnh':0, 'num':0},
    '301-400':{'nan':0, 'hnh':0, 'num':0},
    '401-500':{'nan':0, 'hnh':0, 'num':0},
    '501-1000':{'nan':0, 'hnh':0, 'num':0},
    '1001-2000':{'nan':0, 'hnh':0, 'num':0},
    '2001-3000':{'nan':0, 'hnh':0, 'num':0},
    '3001-4000':{'nan':0, 'hnh':0, 'num':0},
    '4001-5000':{'nan':0, 'hnh':0, 'num':0},
    '5001-6000':{'nan':0, 'hnh':0, 'num':0},
    '6001-15000':{'nan':0, 'hnh':0, 'num':0},    
    }

for hist in hist_dict:
    for istype in ['nan', 'hnh', 'num']:
        tot = max(hist_dict[hist]['tot'],1)
        pct = hist_dict[hist][istype]/tot
        
        hist_pct_dict[hist][istype] = pct
        
hist_pct_dict = {'nan':0, 'hnh':0, 'num':0, 'tot':0}

for hist in hist_dict:
    for istype in ['nan', 'hnh', 'num']:
        
        hist_pct_dict[istype] += hist_dict[hist][istype]
        hist_pct_dict['tot'] += hist_dict[hist]['tot']